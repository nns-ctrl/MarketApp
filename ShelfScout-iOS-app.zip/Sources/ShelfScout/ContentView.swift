import SwiftUI

struct ContentView: View {
    @EnvironmentObject private var store: PriceStore
    @State private var query = ""
    @State private var showBasket = false

    private var results: [GroceryItem] {
        guard !query.isEmpty else { return store.items }
        return store.items.filter { $0.name.localizedCaseInsensitiveContains(query) || $0.category.localizedCaseInsensitiveContains(query) }
    }

    var body: some View {
        NavigationStack {
            List {
                Section {
                    Button { showBasket = true } label: {
                        HStack(spacing: 14) {
                            Image(systemName: "bolt.fill").foregroundStyle(.yellow).font(.title2)
                            VStack(alignment: .leading) {
                                Text("Quick basket compare").font(.headline)
                                Text(store.basket.isEmpty ? "Tap items below, then find your best shop" : "\(store.basket.count) items ready to compare")
                                    .font(.subheadline).foregroundStyle(.secondary)
                            }
                            Spacer(); Image(systemName: "chevron.right").foregroundStyle(.tertiary)
                        }
                    }
                }
                Section("Prices") {
                    ForEach(results) { item in
                        ItemRow(item: item, inBasket: store.basket.contains(item.id)) { store.toggle(item) }
                    }
                }
            }
            .searchable(text: $query, prompt: "Search milk, eggs, chicken…")
            .navigationTitle("Shelf Scout")
            .toolbar {
                ToolbarItem(placement: .topBarTrailing) {
                    Button { Task { await store.refresh() } } label: { Image(systemName: "arrow.clockwise") }
                        .disabled(store.isRefreshing)
                }
            }
            .safeAreaInset(edge: .bottom) {
                Text(store.sourceNote).font(.caption).foregroundStyle(.secondary).padding(8)
                    .frame(maxWidth: .infinity).background(.thinMaterial)
            }
            .sheet(isPresented: $showBasket) { BasketCompareView().environmentObject(store) }
        }
    }
}

private struct ItemRow: View {
    let item: GroceryItem
    let inBasket: Bool
    let toggle: () -> Void
    var body: some View {
        HStack(spacing: 12) {
            Image(systemName: item.icon).frame(width: 28).foregroundStyle(.green)
            VStack(alignment: .leading) {
                Text(item.name).font(.headline); Text(item.size + " • " + item.category).font(.caption).foregroundStyle(.secondary)
                if let cheapest = item.cheapest { Text("Best: \(cheapest.supermarket) · \(PriceFormat.money(cheapest.price))").font(.subheadline).foregroundStyle(.green) }
            }
            Spacer()
            Button(action: toggle) { Image(systemName: inBasket ? "checkmark.circle.fill" : "plus.circle").font(.title3) }
                .buttonStyle(.plain).foregroundStyle(inBasket ? .green : .secondary).accessibilityLabel(inBasket ? "Remove from basket" : "Add to basket")
        }.padding(.vertical, 4)
    }
}
