import SwiftUI

@main
struct ShelfScoutApp: App {
    @StateObject private var store = PriceStore()

    var body: some Scene {
        WindowGroup {
            ContentView()
                .environmentObject(store)
        }
    }
}
