import SwiftUI

struct BasketCompareView: View {
    @EnvironmentObject private var store: PriceStore
    @Environment(\.dismiss) private var dismiss
    private var totals: [(name: String, total: Decimal, covered: Int)] {
        let names = Set(store.selectedItems.flatMap { $0.prices.map(\.supermarket) })
        return names.map { name in
            let values = store.selectedItems.compactMap { item in item.prices.first(where: { $0.supermarket == name })?.price }
            return (name, values.reduce(0, +), values.count)
        }.filter { $0.covered == store.selectedItems.count }.sorted { $0.total < $1.total }
    }
    var body: some View {
        NavigationStack {
            List {
                if store.selectedItems.isEmpty { ContentUnavailableView("Your basket is empty", systemImage: "basket", description: Text("Add products from search to compare a whole shop in one tap.")) }
                else if totals.isEmpty { ContentUnavailableView("No single-store match", systemImage: "building.2", description: Text("Try more comparable products in the live feed.")) }
                else {
                    Section("Best one-stop shop") {
                        ForEach(totals, id: \.name) { result in
                            HStack { VStack(alignment: .leading) { Text(result.name).font(.headline); Text("All \(result.covered) basket items available").font(.caption).foregroundStyle(.secondary) }; Spacer(); Text(PriceFormat.money(result.total)).font(.title3.bold()).foregroundStyle(result.name == totals.first?.name ? .green : .primary) }
                        }
                    }
                    Section("Your items") { ForEach(store.selectedItems) { Text($0.name) } }
                }
            }.navigationTitle("Fast compare").toolbar { ToolbarItem(placement: .topBarTrailing) { Button("Done") { dismiss() } } }
        }
    }
}
