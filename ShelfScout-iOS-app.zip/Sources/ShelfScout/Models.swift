import Foundation

struct StorePrice: Identifiable, Codable, Hashable {
    let id: UUID
    let supermarket: String
    let price: Decimal
    let unitPrice: String
    let checkedAt: Date

    init(id: UUID = UUID(), supermarket: String, price: Decimal, unitPrice: String, checkedAt: Date = .now) {
        self.id = id
        self.supermarket = supermarket
        self.price = price
        self.unitPrice = unitPrice
        self.checkedAt = checkedAt
    }
}

struct GroceryItem: Identifiable, Codable, Hashable {
    let id: UUID
    let name: String
    let category: String
    let size: String
    let icon: String
    let prices: [StorePrice]

    init(id: UUID = UUID(), name: String, category: String, size: String, icon: String, prices: [StorePrice]) {
        self.id = id
        self.name = name
        self.category = category
        self.size = size
        self.icon = icon
        self.prices = prices
    }

    var cheapest: StorePrice? { prices.min { $0.price < $1.price } }
    var highest: StorePrice? { prices.max { $0.price < $1.price } }
    var saving: Decimal { (highest?.price ?? 0) - (cheapest?.price ?? 0) }
}

enum PriceFormat {
    static let currency: NumberFormatter = {
        let formatter = NumberFormatter()
        formatter.numberStyle = .currency
        formatter.currencyCode = "GBP"
        return formatter
    }()

    static func money(_ value: Decimal) -> String {
        currency.string(from: value as NSDecimalNumber) ?? "£0.00"
    }
}
