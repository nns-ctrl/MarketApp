import Foundation

@MainActor
final class PriceStore: ObservableObject {
    @Published private(set) var items: [GroceryItem] = SamplePrices.items
    @Published var basket: Set<UUID> = []
    @Published private(set) var isRefreshing = false
    @Published private(set) var sourceNote = "Demo prices • update with a store-feed endpoint"

    var selectedItems: [GroceryItem] { items.filter { basket.contains($0.id) } }

    func toggle(_ item: GroceryItem) {
        if basket.contains(item.id) { basket.remove(item.id) } else { basket.insert(item.id) }
    }

    func refresh() async {
        isRefreshing = true
        defer { isRefreshing = false }
        // Set SHELFSCOUT_PRICES_URL in the app scheme to a trusted JSON price feed.
        guard let urlString = ProcessInfo.processInfo.environment["SHELFSCOUT_PRICES_URL"],
              let url = URL(string: urlString) else {
            sourceNote = "Demo prices • add a live feed URL in the scheme"
            return
        }
        do {
            let (data, _) = try await URLSession.shared.data(from: url)
            items = try JSONDecoder.shelfScout.decode([GroceryItem].self, from: data)
            sourceNote = "Live feed refreshed just now"
        } catch {
            sourceNote = "Couldn’t refresh live prices — showing saved prices"
        }
    }
}

extension JSONDecoder {
    static let shelfScout: JSONDecoder = {
        let decoder = JSONDecoder()
        decoder.dateDecodingStrategy = .iso8601
        return decoder
    }()
}

enum SamplePrices {
    static let items: [GroceryItem] = [
        GroceryItem(name: "Semi-skimmed milk", category: "Dairy", size: "2 pints", icon: "cup.and.saucer.fill", prices: [
            StorePrice(supermarket: "Aldi", price: 1.45, unitPrice: "72.5p / pint"), StorePrice(supermarket: "Tesco", price: 1.65, unitPrice: "82.5p / pint"), StorePrice(supermarket: "Sainsbury’s", price: 1.60, unitPrice: "80p / pint")]),
        GroceryItem(name: "Free range eggs", category: "Dairy", size: "6 pack", icon: "oval.fill", prices: [
            StorePrice(supermarket: "Lidl", price: 1.79, unitPrice: "29.8p each"), StorePrice(supermarket: "Tesco", price: 2.10, unitPrice: "35p each"), StorePrice(supermarket: "Waitrose", price: 2.45, unitPrice: "40.8p each")]),
        GroceryItem(name: "Sourdough loaf", category: "Bakery", size: "500g", icon: "birthday.cake.fill", prices: [
            StorePrice(supermarket: "Aldi", price: 1.89, unitPrice: "37.8p / 100g"), StorePrice(supermarket: "Morrisons", price: 2.20, unitPrice: "44p / 100g"), StorePrice(supermarket: "Tesco", price: 2.35, unitPrice: "47p / 100g")]),
        GroceryItem(name: "British chicken breast", category: "Meat", size: "600g", icon: "fork.knife", prices: [
            StorePrice(supermarket: "Lidl", price: 4.39, unitPrice: "73.2p / 100g"), StorePrice(supermarket: "Asda", price: 4.75, unitPrice: "79.2p / 100g"), StorePrice(supermarket: "Sainsbury’s", price: 5.25, unitPrice: "87.5p / 100g")]),
        GroceryItem(name: "Fairtrade bananas", category: "Fruit & veg", size: "5 pack", icon: "leaf.fill", prices: [
            StorePrice(supermarket: "Aldi", price: 0.85, unitPrice: "17p each"), StorePrice(supermarket: "Tesco", price: 1.05, unitPrice: "21p each"), StorePrice(supermarket: "Waitrose", price: 1.35, unitPrice: "27p each")])
    ]
}
