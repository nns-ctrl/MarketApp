import XCTest
@testable import ShelfScout

final class ShelfScoutTests: XCTestCase {
    func testCheapestPriceAndSaving() {
        let item = GroceryItem(name: "Test", category: "Test", size: "1", icon: "cart", prices: [
            StorePrice(supermarket: "A", price: 2.50, unitPrice: "£2.50"),
            StorePrice(supermarket: "B", price: 1.25, unitPrice: "£1.25")])
        XCTAssertEqual(item.cheapest?.supermarket, "B")
        XCTAssertEqual(item.saving, 1.25)
    }
}
